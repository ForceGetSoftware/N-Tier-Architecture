﻿namespace N_Tier.Application.Models.TodoList;

public class CreateTodoListModel
{
    public string Title { get; set; }
}

public class CreateTodoListResponseModel : BaseResponseModel { }
