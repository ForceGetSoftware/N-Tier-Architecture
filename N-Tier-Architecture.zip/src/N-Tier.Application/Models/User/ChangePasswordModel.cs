﻿namespace N_Tier.Application.Models.User;

public class ChangePasswordModel
{
    public string OldPassword { get; set; }

    public string NewPassword { get; set; }
}
