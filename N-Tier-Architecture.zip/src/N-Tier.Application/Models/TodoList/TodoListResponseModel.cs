﻿namespace N_Tier.Application.Models.TodoList;

public class TodoListResponseModel : BaseResponseModel
{
    public string Title { get; set; }
}
